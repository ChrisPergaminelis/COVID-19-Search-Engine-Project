import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import javax.swing.JFileChooser;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class CsvToText {
	
	private static JFileChooser fc = new JFileChooser();
	
	public static void main(String[] args) throws IOException, CsvValidationException {
		Scanner scanner = new Scanner(System.in);
		int max_lines = scanner.nextInt();
		scanner.close();
		File csv_file = new File(selectFile());
		File txt_directory = new File(selectFile());
		CSVReader reader = new CSVReader(new FileReader(csv_file, StandardCharsets.UTF_8));
	    String [] nextLine;
	    PrintWriter printWriter;
	    int lines_read = 0;
	    while ((nextLine = reader.readNext()) != null) {
	    	if (lines_read == 0) {
	    		lines_read++;
	    		continue;
	    	} else if (lines_read > max_lines) {
	    		reader.close();
	    		return;
	    	} else {
	    		File txt_file = new File(txt_directory, lines_read+".txt");
	    		printWriter = new PrintWriter(txt_file, StandardCharsets.UTF_8);
	    		if(nextLine[0].equals("")) {
	    			nextLine[0] = "Anonymous Author";
	    		}
	    		printWriter.print(nextLine[3]+'\n'+nextLine[0]+'\n'+nextLine[1]+'\n'+nextLine[5]);
	    		printWriter.close();
	    		lines_read++;
	    	}
	    }
	}
	
	private static String selectFile() {
		String directory = null;
		int r;
		fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		do {
			r = fc.showOpenDialog(null);
		} while (r == JFileChooser.ERROR_OPTION);
		try {
			directory = fc.getSelectedFile().getCanonicalPath().toString();
			System.out.println(directory);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return directory;
	}
	
}
